NASA C-MAPSS turbofan engine data - subset FD001
(one operating condition, one fault mode: HPC degradation)

train_FD001.txt  20,631 rows - 100 engines run until failure
test_FD001.txt   13,096 rows - 100 engines, records stop before failure
RUL_FD001.txt    100 rows    - true remaining cycles for each test engine (line 1 = engine 1)

Format: space-separated, no header, 26 columns:
  1 unit (engine id), 2 cycle, 3-5 operational settings 1-3, 6-26 sensors s1-s21
Load in pandas:
  pd.read_csv("train_FD001.txt", sep=r"\s+", header=None)

Note: these files were rebuilt from a Kaggle copy of the dataset, with the same values
as NASA's original. Only trailing zeros differ (e.g. 1589.7 vs 1589.70).

Cite in your README:
A. Saxena, K. Goebel, D. Simon and N. Eklund, "Damage Propagation Modeling for
Aircraft Engine Run-to-Failure Simulation", Proceedings of the 1st International
Conference on Prognostics and Health Management (PHM08), Denver, CO, Oct 2008.
Source: NASA Prognostics Center of Excellence (PCoE) Data Set Repository.
